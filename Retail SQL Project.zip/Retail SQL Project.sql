## create database
create database retail;

use retail;


## create tables


-- Sellers
create table sellers(
seller_id varchar(225) primary key,
seller_zip_code_prefix int not null,
seller_city varchar(225) not null,
seller_state varchar(100) not null);

-- Customers
create table customers(
customer_id varchar(225) primary key,
customer_unique_id varchar(225) not null,
customer_zip_code_prefix int not null,
customer_city varchar(225) not null,
customer_state varchar(225) not null);


-- Products
create table products(
product_id varchar(225) primary key,
product_category varchar(225) null,
product_name_length text null,
product_description_length text null,
product_photos_qty text null,
product_weight_g text null,
product_length_cm text null,
product_height_cm text null,
product_width_cm text null);



-- Geolocation
create table geolocation(
geolocation_zip_code_prefix int not null,
geolocation_lat text not null,
geolocation_lng text not null,
geolocation_city varchar(225) not null,
geolocation_state varchar(225) not null);


-- Orders
create table orders(
order_id varchar(225) primary key,
customer_id varchar(225) not null,
order_status varchar(225) not null,
order_purchase_timestamp text not null,
order_approved_at text null,
order_delivered_carrier_date text null,
order_delivered_customer_date text null,
order_estimated_delivery_date text not null,
foreign key(customer_id) references customers(customer_id));



-- Payments
create table payments(
order_id varchar(225),
payment_sequential tinyint not null,
payment_type varchar(225) not null,
payment_installments tinyint not null,
payment_value decimal not null,
foreign key(order_id) references orders(order_id));


-- Order_review
create table order_review(
review_id varchar(225) primary key,
order_id varchar(225),
review_score tinyint not null,
review_comment_title text,
review_creation_date text not null,
review_answer_timestamp text not null,
foreign key(order_id) references orders(order_id));



-- order_item
create table order_item(
order_id varchar(225),
order_item_id char(20),
product_id varchar(225),
seller_id varchar(225),
shipping_limit_date text not null,
price text not null,
freight_value decimal not null,
foreign key(order_id) references orders(order_id),
foreign key(product_id) references products(product_id),
foreign key(seller_id) references sellers(seller_id));

## geolocation
LOAD DATA INFILE 'geolocation.csv'
INTO TABLE geolocation
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(geolocation_zip_code_prefix, geolocation_lat ,geolocation_lng,
geolocation_city, geolocation_state);



## customers
LOAD DATA INFILE 'customers.csv'
INTO
TABLE customers
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(customer_id, customer_unique_id, customer_zip_code_prefix, customer_city,
customer_state);


## orders
LOAD DATA INFILE 'orders.csv'
INTO TABLE orders
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(order_id, customer_id, order_status, order_purchase_timestamp, order_approved_at,
order_delivered_carrier_date,
order_delivered_customer_date, order_estimated_delivery_date);



## payments
LOAD DATA INFILE 'payments.csv'
INTO TABLE payments
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(order_id ,payment_sequential ,payment_type, payment_installments
,payment_value);


## Order_review
LOAD DATA INFILE 'order_reviews.csv'
REPLACE
INTO TABLE order_review
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(review_id, order_id, review_score, review_creation_date, review_answer_timestamp);




## sellers
LOAD DATA INFILE 'sellers.csv'
INTO TABLE sellers
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(seller_id, seller_zip_code_prefix, seller_city, seller_state
);

## order_item
LOAD DATA INFILE 'order_items.csv'
REPLACE
INTO TABLE order_item
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(order_id, order_item_id, product_id, seller_id, shipping_limit_date,
price, freight_value
);


## products
LOAD DATA INFILE 'products.csv'
INTO TABLE products
FIELDS TERMINATED BY ','
ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS
(product_id, `product category`, product_name_length, product_description_length,
product_photos_qty, product_weight_g,
product_length_cm, product_height_cm, product_width_cm);


## -- order_item
create table order_item(
order_id varchar(225),
order_item_id char(20),
product_id varchar(225),
seller_id varchar(225),
shipping_limit_date text not null,
price text not null,
freight_value decimal not null,
foreign key(order_id) references orders(order_id),
foreign key(product_id) references products(product_id),
foreign key(seller_id) references sellers(seller_id));




## Assignment Tasks

# ● Customer Analysis
# 1. Find the total number of unique customers.

SELECT COUNT(DISTINCT customer_id) AS total_unique_customers
FROM Customers;


# 2. Identify the top 5 states with the highest number of customers.

SELECT customer_state, COUNT(*) AS total_customers
FROM Customers
GROUP BY customer_state
ORDER BY total_customers DESC
LIMIT 5;


# 3. Calculate customer retention rate (customers who placed more than 1 order).

WITH order_counts AS (
    SELECT 
        customer_id,
        COUNT(order_id) AS total_orders
    FROM orders
    GROUP BY customer_id
),
retention AS (
    SELECT 
        (SELECT COUNT(*) FROM order_counts WHERE total_orders > 1) AS retained_customers,
        (SELECT COUNT(*) FROM order_counts) AS total_customers
)
SELECT 
    retained_customers,
    total_customers,
    (retained_customers * 100.0 / total_customers) AS retention_rate
FROM retention;

# 4. Find customers who gave the lowest review scores more than twice


SELECT 
    o.customer_id,
    COUNT(*) AS low_score_count
FROM order_review r
JOIN orders o 
    ON r.order_id = o.order_id
WHERE r.review_score = 1
GROUP BY o.customer_id
HAVING COUNT(*) > 2;

# ● Order & Delivery Analysis
# 1. Count the total number of delivered vs. canceled orders.

SELECT 
    order_status,
    COUNT(*) AS total_orders
FROM orders
WHERE order_status IN ('delivered', 'canceled')
GROUP BY order_status;


# 2. Calculate the average delivery time for delivered orders.

SELECT 
    AVG(DATEDIFF(order_delivered_customer_date, order_purchase_timestamp)) AS avg_delivery_time_days
FROM orders
WHERE order_status = 'delivered';


# 3. Identify the top 5 cities with the fastest delivery times.

SELECT 
    c.customer_city,
    AVG(DATEDIFF(o.order_delivered_customer_date, o.order_purchase_timestamp)) AS avg_delivery_days
FROM orders o
JOIN customers c
    ON o.customer_id = c.customer_id
WHERE o.order_status = 'delivered'
GROUP BY c.customer_city
HAVING AVG(DATEDIFF(o.order_delivered_customer_date, o.order_purchase_timestamp)) IS NOT NULL
ORDER BY avg_delivery_days ASC
LIMIT 5;



# 4. Determine the percentage of orders delivered late vs. estimated date. 

WITH delivery_status AS (
    SELECT
        order_id,
        CASE 
            WHEN order_status = 'delivered' 
                 AND order_delivered_customer_date > order_estimated_delivery_date 
            THEN 1 ELSE 0 
        END AS is_late
    FROM orders
    WHERE order_status = 'delivered'
)
SELECT
    SUM(is_late) AS late_orders,
    COUNT(*) AS total_delivered_orders,
    (SUM(is_late) * 100.0 / COUNT(*)) AS late_delivery_percentage
FROM delivery_status;




# 5.Find the month with the maximum number of orders.

SELECT 
    DATE_FORMAT(order_purchase_timestamp, '%Y-%m') AS order_month,
    COUNT(*) AS total_orders
FROM orders
GROUP BY order_month
ORDER BY total_orders DESC
LIMIT 1;

# ● Product & Category Analysis.

# 1. Find the top 10 most sold product categories.

SELECT 
    p.product_category,
    COUNT(*) AS total_sold
FROM order_item oi
JOIN products p
    ON oi.product_id = p.product_id
WHERE p.product_category IS NOT NULL
  AND p.product_category <> ''
GROUP BY p.product_category
ORDER BY total_sold DESC
LIMIT 10;


# 2. Calculate average weight, length, height, and width for products in each category.

SELECT
    product_category,
    
    AVG(CAST(product_weight_g AS DECIMAL(10,2))) AS avg_weight_g,
    AVG(CAST(product_length_cm AS DECIMAL(10,2))) AS avg_length_cm,
    AVG(CAST(product_height_cm AS DECIMAL(10,2))) AS avg_height_cm,
    AVG(CAST(product_width_cm AS DECIMAL(10,2))) AS avg_width_cm

FROM products
WHERE product_category IS NOT NULL
GROUP BY product_category;

# -. Identify products with the highest freight-to-price ratio.

SELECT 
    oi.product_id,
    p.product_category,
    oi.price,
    oi.freight_value,
    (oi.freight_value / oi.price) AS freight_price_ratio
FROM order_item oi
JOIN products p 
    ON oi.product_id = p.product_id
WHERE oi.price > 0
ORDER BY freight_price_ratio DESC
LIMIT 10;

DESCRIBE order_item;

SELECT 
    oi.product_id,
    p.product_category,
    CAST(oi.price AS DECIMAL(10,2)) AS price,
    oi.freight_value,
    (oi.freight_value / CAST(oi.price AS DECIMAL(10,2))) AS freight_price_ratio
FROM order_item oi
JOIN products p 
    ON oi.product_id = p.product_id
WHERE 
    oi.price IS NOT NULL
    AND oi.price <> ''
    AND CAST(oi.price AS DECIMAL(10,2)) > 0
ORDER BY freight_price_ratio DESC
LIMIT 10;



# 3. Find the top 3 products (by revenue) in each category


WITH product_revenue AS (
    SELECT 
        p.product_category AS category,
        p.product_id,
        SUM(CAST(oi.price AS DECIMAL(10,2))) AS total_revenue,
        ROW_NUMBER() OVER (
            PARTITION BY p.product_category
            ORDER BY SUM(CAST(oi.price AS DECIMAL(10,2))) DESC
        ) AS rn
    FROM products p
    JOIN order_item oi 
        ON p.product_id = oi.product_id
    GROUP BY p.product_category, p.product_id
)

SELECT 
    category,
    product_id,
    total_revenue
FROM product_revenue
WHERE rn <= 3
ORDER BY category, total_revenue DESC;



# Payment & Revenue Analysis


# 1. Find the most common payment type.

SELECT 
    payment_type,
    COUNT(*) AS total_payments
FROM payments
GROUP BY payment_type
ORDER BY total_payments DESC
LIMIT 1;



#2. Calculate revenue by payment type

SELECT 
    payment_type,
    SUM(payment_value) AS total_revenue
FROM payments
GROUP BY payment_type
ORDER BY total_revenue DESC;



#3. Determine the average number of installments for credit card payments. 

SELECT 
    ROUND(AVG(payment_installments), 2) AS avg_installments
FROM payments
WHERE payment_type = 'credit_card';

 
#4. Findthe top 5 highest-value orders and their payment details.

SELECT 
    p.order_id,
    p.payment_type,
    p.payment_installments,
    p.payment_value,
    o.total_order_value
FROM payments p
JOIN (
    SELECT 
        order_id,
        SUM(payment_value) AS total_order_value
    FROM payments
    GROUP BY order_id
    ORDER BY total_order_value DESC
    LIMIT 5
) o
ON p.order_id = o.order_id
ORDER BY o.total_order_value DESC;


# ● Review Analysis

# 1. Find the average review score per product category.

SELECT 
    p.product_category,
    ROUND(AVG(r.review_score), 2) AS avg_review_score
FROM products p
JOIN order_item oi 
    ON p.product_id = oi.product_id
JOIN orders o 
    ON oi.order_id = o.order_id
JOIN order_review r 
    ON o.order_id = r.order_id
GROUP BY p.product_category
ORDER BY avg_review_score DESC;

# 2. Identify sellers consistently receiving reviews below 3.

SELECT 
    s.seller_id,
    ROUND(AVG(r.review_score), 2) AS avg_review_score,
    COUNT(r.review_id) AS total_reviews
FROM sellers s
JOIN order_item oi 
    ON s.seller_id = oi.seller_id
JOIN orders o 
    ON oi.order_id = o.order_id
JOIN order_review r 
    ON o.order_id = r.order_id
GROUP BY s.seller_id
HAVING AVG(r.review_score) < 3
ORDER BY avg_review_score ASC;

# 3. Determine if there is a correlation between delivery time and review score.
 SELECT 
    TIMESTAMPDIFF(
        DAY,
        o.order_purchase_timestamp,
        o.order_delivered_customer_date
    ) AS delivery_days,
    ROUND(AVG(r.review_score), 2) AS avg_review_score,
    COUNT(*) AS total_orders
FROM orders o
JOIN order_review r 
    ON o.order_id = r.order_id
WHERE o.order_delivered_customer_date IS NOT NULL
GROUP BY delivery_days
ORDER BY delivery_days;

 
 
# Find the distribution of review scores across states.
SELECT 
    c.customer_state,
    r.review_score,
    COUNT(*) AS total_reviews
FROM customers c
JOIN orders o 
    ON c.customer_id = o.customer_id
JOIN order_review r 
    ON o.order_id = r.order_id
GROUP BY c.customer_state, r.review_score
ORDER BY c.customer_state, r.review_score;


# ● Seller & Location Analysis

# 1. Count the number of sellers per state.
SELECT 
    seller_state,
    COUNT(*) AS total_sellers
FROM sellers
GROUP BY seller_state
ORDER BY total_sellers DESC;


# 2. Find sellers with the highest total sales revenue.

SELECT 
    oi.seller_id,
    ROUND(SUM(oi.price + oi.freight_value), 2) AS total_revenue
FROM order_item oi
GROUP BY oi.seller_id
ORDER BY total_revenue DESC;

# 3. Identify the top 5 cities with the highest seller density.

SELECT 
    seller_city,
    seller_state,
    COUNT(*) AS total_sellers
FROM sellers
GROUP BY seller_city, seller_state
ORDER BY total_sellers DESC
LIMIT 5;


# 4. Match customers and sellers by ZIP code to find local transactions.

SELECT 
    o.order_id,
    c.customer_id,
    s.seller_id,
    c.customer_zip_code_prefix AS customer_zip,
    s.seller_zip_code_prefix AS seller_zip
FROM orders o
JOIN customers c 
    ON o.customer_id = c.customer_id
JOIN order_item oi 
    ON o.order_id = oi.order_id
JOIN sellers s 
    ON oi.seller_id = s.seller_id
WHERE c.customer_zip_code_prefix = s.seller_zip_code_prefix;


# ● Advanced Analytics

# 1. Calculate monthly revenue growth and plot a trend line.

SELECT
    DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m') AS month,
    ROUND(SUM(p.payment_value), 2) AS monthly_revenue,
    ROUND(
        (
            SUM(p.payment_value) -
            LAG(SUM(p.payment_value)) OVER (ORDER BY DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m'))
        ) /
        LAG(SUM(p.payment_value)) OVER (ORDER BY DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m')) * 100,
        2
    ) AS revenue_growth_percentage
FROM orders o
JOIN payments p
    ON o.order_id = p.order_id
GROUP BY month
ORDER BY month;



# 2. Analyze customer purchase frequency (one-time vs. repeat). 

SELECT
    customer_id,
    COUNT(order_id) AS total_orders
FROM orders
GROUP BY customer_id;

SELECT
    CASE
        WHEN order_count = 1 THEN 'One-time Customer'
        ELSE 'Repeat Customer'
    END AS customer_type,
    COUNT(*) AS total_customers
FROM (
    SELECT
        customer_id,
        COUNT(order_id) AS order_count
    FROM orders
    GROUP BY customer_id
) t
GROUP BY customer_type;

# 3.Find the contribution percentage of each product category to overall revenue. - Identify the top 3 sellers in each state by revenue.

SELECT
    seller_state,
    seller_id,
    total_revenue
FROM (
    SELECT
        s.seller_state,
        oi.seller_id,
        ROUND(SUM(oi.price + oi.freight_value), 2) AS total_revenue,
        ROW_NUMBER() OVER (
            PARTITION BY s.seller_state
            ORDER BY SUM(oi.price + oi.freight_value) DESC
        ) AS revenue_rank
    FROM sellers s
    JOIN order_item oi
        ON s.seller_id = oi.seller_id
    GROUP BY s.seller_state, oi.seller_id
) ranked_sellers
WHERE revenue_rank <= 3
ORDER BY seller_state, total_revenue DESC;

